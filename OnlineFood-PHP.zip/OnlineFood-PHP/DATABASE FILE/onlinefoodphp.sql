-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2022 at 08:45 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onlinefoodphp`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adm_id` int(222) NOT NULL,
  `username` varchar(222) NOT NULL,
  `password` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `code` varchar(222) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adm_id`, `username`, `password`, `email`, `code`, `date`) VALUES
(1, 'admin', 'CAC29D7A34687EB14B37068EE4708E7B', 'admin@mail.com', '', '2022-05-27 13:21:52');

-- --------------------------------------------------------

--
-- Table structure for table `dishes`
--

CREATE TABLE `dishes` (
  `d_id` int(222) NOT NULL,
  `rs_id` int(222) NOT NULL,
  `title` varchar(222) NOT NULL,
  `slogan` varchar(222) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `img` varchar(222) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dishes`
--

INSERT INTO `dishes` (`d_id`, `rs_id`, `title`, `slogan`, `price`, `img`) VALUES
(2, 6, 'Rocky Road (Small)', 'Newest Milktea Favorites', '80.00', '62a16ca23ad51.jpg'),
(17, 6, 'Cookieccino (Small)', 'Newest Milktea Favorites', '70.00', '62a16d6bbda4d.jpg'),
(18, 6, 'Oreo Strawberry (Small)', 'Newest Milktea Favorites', '65.00', '62a16dc7c0033.jpg'),
(19, 6, 'F3', 'Burger + Fries + Juice', '35.00', '62a017b5cf458.jpg'),
(20, 6, 'F4', 'Milktea + Burger with Fries', '90.00', '62a016003c9b7.jpg'),
(21, 6, 'F6', '2 pcs Footlong + Fries + Juice', '90.00', '62a0166771599.jpg'),
(22, 6, 'F7', 'Burger with Egg + Fries + Juice', '50.00', '62a06e0587c24.jpg'),
(23, 6, 'Burger', 'Buy 1 Take 1', '25.00', '62a016bc8ba24.jpg'),
(24, 6, 'Cheeseburger', 'Buy 1 Take 1', '35.00', '62a016e47f480.jpg'),
(25, 6, 'Hotdog Sandwich', 'Buy 1 Take 1', '35.00', '62a06e2fb29f5.jpg'),
(26, 6, 'Okinawa (Small)', 'Milktea Favorites', '50.00', '62a06e931248a.jpeg'),
(27, 6, 'Okinawa (Medium)', 'Milktea Favorites', '65.00', '62a05d0551d3d.jpeg'),
(28, 6, 'Okinawa (Large)', 'Milktea Favorites', '75.00', '62a05d316349b.jpeg'),
(29, 6, 'Okinawa (XL)', 'Milktea Favorites', '110.00', '62a05d60193be.jpeg'),
(30, 6, 'Classic (Small)', 'Milktea Favorites', '40.00', '62a05e6d9d1e0.jpeg'),
(31, 6, 'Classic (Medium)', 'Milktea Favorites', '55.00', '62a05e948d18b.jpeg'),
(32, 6, 'Classic (Large)', 'Milktea Favorites', '65.00', '62a05ee34b10e.jpeg'),
(33, 6, 'Classic (XL)', 'Milktea Favorites', '90.00', '62a05f371d760.jpeg'),
(34, 6, 'Wintermelon (Small)', 'Milktea Favorites', '50.00', '62a05fa0442ff.jpeg'),
(35, 6, 'Wintermelon (Medium)', 'Milktea Favorites', '65.00', '62a05fc1c507e.jpeg'),
(36, 6, 'Wintermelon (Large)', 'Milktea Favorites', '75.00', '62a05fedb099b.jpeg'),
(37, 6, 'Wintermelon (XL)', 'Milktea Favorites', '110.00', '62a0602fde7b8.jpeg'),
(40, 6, 'Choco Hazelnut (Small)', 'Milktea Favorites', '55.00', '62a06148e91de.jpeg'),
(41, 6, 'Choco Hazelnut (Medium)', 'Milktea Favorites', '65.00', '62a061757619d.jpeg'),
(42, 6, 'Choco Hazelnut (Large)', 'Milktea Favorites', '75.00', '62a061b0bb835.jpeg'),
(43, 6, 'Choco Hazelnut (XL)', 'Milktea Favorites', '110.00', '62a061d46f8e7.jpeg'),
(45, 6, 'Dark Chocolate (Small)', 'Milktea Favorites', '55.00', '62a062b57a740.jpeg'),
(46, 6, 'Dark Chocolate (Medium)', 'Milktea Favorites', '65.00', '62a062d079123.jpeg'),
(47, 6, 'Dark Chocolate (Large)', 'Milktea Favorites', '75.00', '62a06315137ff.jpeg'),
(48, 6, 'Dark Chocolate (XL)', 'Milktea Favorites', '110.00', '62a06347a6db0.jpeg'),
(49, 6, 'Taro (Small)', 'Milktea Favorites', '50.00', '62a063a22b1dc.jpeg'),
(50, 6, 'Taro (Medium)', 'Milktea Favorites', '65.00', '62a063c751df4.jpeg'),
(51, 6, 'Taro (Large)', 'Milktea Favorites', '75.00', '62a063e7d7eec.jpeg'),
(52, 6, 'Taro (XL)', 'Milktea Favorites', '100.00', '62a06405c066a.jpeg'),
(53, 6, 'Oreo Cheesecake (Small)', 'Milktea Favorites', '65.00', '62a064599e4fe.jpeg'),
(54, 6, 'Oreo Cheesecake (Medium)', 'Milktea Favorites', '80.00', '62a0647cb9551.jpeg'),
(55, 6, 'Oreo Cheesecake (Large)', 'Milktea Favorites', '90.00', '62a0649f9d955.jpeg'),
(56, 6, 'Oreo Cheesecake (XL)', 'Milktea Favorites', '130.00', '62a064beb05cf.jpeg'),
(57, 6, 'Nutella (Small)', 'Milktea Favorites', '80.00', '62a06588ea1bf.jpeg'),
(58, 6, 'Nutella (Medium)', 'Milktea Favorites', '90.00', '62a065afda93c.jpeg'),
(59, 6, 'Nutella (Large)', 'Milktea Favorites', '110.00', '62a065da43317.jpeg'),
(60, 6, 'Nutella (XL)', 'Milktea Favorites', '130.00', '62a065fcd2160.jpeg'),
(61, 6, 'Ube (Small)', 'Fruit Milktea Series', '50.00', '62a0663ba25cd.jpeg'),
(62, 6, 'Ube (Medium)', 'Fruit Milktea Series', '65.00', '62a0666267b3c.jpeg'),
(63, 6, 'Ube (Large)', 'Fruit Milktea Series', '75.00', '62a06680ad454.jpeg'),
(64, 6, 'Ube (XL)', 'Fruit Milktea Series', '110.00', '62a066a31dc94.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `remark`
--

CREATE TABLE `remark` (
  `id` int(11) NOT NULL,
  `frm_id` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `remark` mediumtext NOT NULL,
  `remarkDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `remark`
--

INSERT INTO `remark` (`id`, `frm_id`, `status`, `remark`, `remarkDate`) VALUES
(1, 2, 'in process', 'none', '2022-05-01 05:17:49'),
(2, 3, 'in process', 'none', '2022-05-27 11:01:30'),
(3, 2, 'closed', 'thank you for your order!', '2022-05-27 11:11:41'),
(4, 3, 'closed', 'none', '2022-05-27 11:42:35'),
(5, 4, 'in process', 'none', '2022-05-27 11:42:55'),
(6, 1, 'rejected', 'none', '2022-05-27 11:43:26'),
(7, 7, 'in process', 'none', '2022-05-27 13:03:24'),
(8, 8, 'in process', 'none', '2022-05-27 13:03:38'),
(9, 9, 'rejected', 'thank you', '2022-05-27 13:03:53'),
(10, 7, 'closed', 'thank you for your ordering with us', '2022-05-27 13:04:33'),
(11, 8, 'closed', 'thanks ', '2022-05-27 13:05:24'),
(12, 5, 'closed', 'none', '2022-05-27 13:18:03'),
(13, 10, 'closed', 'Thank you for ordering!', '2022-06-07 10:44:53'),
(14, 4, 'closed', 'Thank you for ordering!', '2022-06-07 13:00:00'),
(15, 4, 'closed', 'Thank you for ordering!', '2022-06-07 13:00:49'),
(16, 11, 'closed', 'Thank you for ordering!', '2022-06-08 04:20:21'),
(17, 6, 'closed', 'Thank you!', '2022-06-08 04:21:33'),
(18, 12, 'closed', 'Thanks!', '2022-06-08 04:22:15'),
(19, 13, 'closed', 'Thanks!', '2022-06-08 04:22:30'),
(20, 14, 'in process', 'Otw', '2022-06-08 04:41:05'),
(21, 14, 'closed', 'Thanks!', '2022-06-08 04:41:29'),
(22, 15, 'closed', 'Thank you!', '2022-06-09 05:08:40');

-- --------------------------------------------------------

--
-- Table structure for table `restaurant`
--

CREATE TABLE `restaurant` (
  `rs_id` int(222) NOT NULL,
  `c_id` int(222) NOT NULL,
  `title` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `phone` varchar(222) NOT NULL,
  `url` varchar(222) NOT NULL,
  `o_hr` varchar(222) NOT NULL,
  `c_hr` varchar(222) NOT NULL,
  `o_days` varchar(222) NOT NULL,
  `address` text NOT NULL,
  `image` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `restaurant`
--

INSERT INTO `restaurant` (`rs_id`, `c_id`, `title`, `email`, `phone`, `url`, `o_hr`, `c_hr`, `o_days`, `address`, `image`, `date`) VALUES
(6, 5, 'Fornalitea', 'fornalitea@gmail.com', '09776840378', 'https://www.facebook.com/fornalitea', '10am', '8pm', 'Mon-Fri', ' Blk 58 Lot 6 Phase 4 Mabuhay City, Paliparan 3 Dasmarinas City, Cavite', '62a07794aeb7c.jpg', '2022-06-08 10:19:00');

-- --------------------------------------------------------

--
-- Table structure for table `res_category`
--

CREATE TABLE `res_category` (
  `c_id` int(222) NOT NULL,
  `c_name` varchar(222) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `res_category`
--

INSERT INTO `res_category` (`c_id`, `c_name`, `date`) VALUES
(5, 'Snacks and Drinks', '2022-06-09 06:44:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `u_id` int(222) NOT NULL,
  `username` varchar(222) NOT NULL,
  `f_name` varchar(222) NOT NULL,
  `l_name` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `phone` varchar(222) NOT NULL,
  `password` varchar(222) NOT NULL,
  `address` text NOT NULL,
  `brgy` varchar(255) NOT NULL,
  `status` int(222) NOT NULL DEFAULT '1',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`u_id`, `username`, `f_name`, `l_name`, `email`, `phone`, `password`, `address`, `brgy`, `status`, `date`) VALUES
(1, 'eric', 'Eric', 'Lopez', 'eric@mail.com', '1458965547', 'a32de55ffd7a9c4101a0c5c8788b38ed', '87 Armbrester Drive', 'Mabuhay City', 1, '2022-06-09 06:42:17'),
(2, 'harry', 'Harry', 'Holt', 'harryh@mail.com', '3578545458', 'bc28715006af20d0e961afd053a984d9', '33 Stadium Drive', 'Mabuhay City', 1, '2022-06-09 06:42:16'),
(3, 'james', 'James', 'Duncan', 'james@mail.com', '0258545696', '58b2318af54435138065ee13dd8bea16', '67 Hiney Road', 'San Marino City', 1, '2022-06-09 06:42:16'),
(4, 'christine', 'Christine', 'Moore', 'christine@mail.com', '7412580010', '5f4dcc3b5aa765d61d8327deb882cf99', '114 Test Address', 'San Marino City', 1, '2022-06-09 06:42:16'),
(5, 'scott', 'Scott', 'Miller', 'scott@mail.com', '7896547850', '5f4dcc3b5aa765d61d8327deb882cf99', '63 Charack Road', 'Paliparan 3 Site', 1, '2022-06-09 06:42:16'),
(6, 'liamoore', 'Liam', 'Moore', 'liamoore@mail.com', '7896969696', '5f4dcc3b5aa765d61d8327deb882cf99', '122 Bleck Street', 'San Marino City', 1, '2022-06-09 06:42:16'),
(7, 'mikay', 'Mikay', 'Diaz', 'mikay@gmail.com', '09500865543', '379e3f7aa50ca05d8834043fe52978d6', 'Paliparan 3 Dasmarinas City Cavite', 'Mabuhay City', 1, '2022-06-09 06:42:17'),
(8, 'ailene', 'Ailene', 'Pontines', 'ailenepontines@gmail.com', '09500832242', '69d4ff937c07bb8a12c254d6cd2cc6de', 'Phase 3, Paliparan 3 Dasmarinas City Cavite', 'Paliparan 3 Site', 1, '2022-06-09 06:42:17'),
(10, 'jairus', 'Jairus Ash', 'Diaz', 'jairus@gmail.com', '09877678841', 'eb38db69b8822e4973bc141f017eeba7', 'Block 124 Lot 31 Phase 3', 'Mabuhay City', 1, '2022-06-09 06:42:17'),
(11, 'anabelle', 'Anabelle', 'Pontines', 'anabelle@gmail.com', '09544678821', '7a44ab152975420dd0d807a5b46ad446', 'Block 124 Lot 31 Phase 3', 'Mabuhay City', 1, '2022-06-09 06:42:17'),
(12, 'karen', 'Karen', 'Orsal', 'karen@gmail.com', '09655678841', '33b025fbad4d9f7ed30d4e1cc43bed22', 'Block 111 Lot 13 Phase 3', 'Paliparan 3 Site', 1, '2022-06-09 06:42:17');

-- --------------------------------------------------------

--
-- Table structure for table `users_orders`
--

CREATE TABLE `users_orders` (
  `o_id` int(222) NOT NULL,
  `u_id` int(222) NOT NULL,
  `title` varchar(222) NOT NULL,
  `quantity` int(222) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `status` varchar(222) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users_orders`
--

INSERT INTO `users_orders` (`o_id`, `u_id`, `title`, `quantity`, `price`, `status`, `date`) VALUES
(1, 4, 'Spring Rolls', 2, '6.00', 'rejected', '2022-05-27 11:43:26'),
(2, 4, 'Prawn Crackers', 1, '7.00', 'closed', '2022-05-27 11:11:41'),
(3, 5, 'Chicken Madeira', 1, '23.00', 'closed', '2022-05-27 11:42:35'),
(4, 5, 'Cheesy Mashed Potato', 1, '5.00', 'closed', '2022-06-07 13:00:00'),
(5, 5, 'Meatballs Penne Pasta', 1, '10.00', 'closed', '2022-05-27 13:18:03'),
(6, 5, 'Yorkshire Lamb Patties', 1, '14.00', 'closed', '2022-06-08 04:21:34'),
(7, 6, 'Yorkshire Lamb Patties', 1, '14.00', 'closed', '2022-05-27 13:04:33'),
(8, 6, 'Lobster Thermidor', 1, '36.00', 'closed', '2022-05-27 13:05:24'),
(9, 6, 'Stuffed Jacket Potatoes', 1, '8.00', 'rejected', '2022-05-27 13:03:53'),
(10, 7, 'Yorkshire Lamb Patties', 3, '14.00', 'closed', '2022-06-07 10:44:53'),
(11, 7, 'Yorkshire Lamb Patties', 3, '14.00', 'closed', '2022-06-08 04:20:21'),
(12, 8, 'F1', 1, '25.00', 'closed', '2022-06-08 04:22:15'),
(13, 8, 'F2', 1, '25.00', 'closed', '2022-06-08 04:22:30'),
(14, 8, 'F1', 1, '25.00', 'closed', '2022-06-08 04:41:29'),
(15, 8, 'Rocky Road (Small)', 1, '80.00', 'closed', '2022-06-09 05:08:41');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adm_id`);

--
-- Indexes for table `dishes`
--
ALTER TABLE `dishes`
  ADD PRIMARY KEY (`d_id`);

--
-- Indexes for table `remark`
--
ALTER TABLE `remark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `restaurant`
--
ALTER TABLE `restaurant`
  ADD PRIMARY KEY (`rs_id`);

--
-- Indexes for table `res_category`
--
ALTER TABLE `res_category`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`u_id`);

--
-- Indexes for table `users_orders`
--
ALTER TABLE `users_orders`
  ADD PRIMARY KEY (`o_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `adm_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `dishes`
--
ALTER TABLE `dishes`
  MODIFY `d_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `remark`
--
ALTER TABLE `remark`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `restaurant`
--
ALTER TABLE `restaurant`
  MODIFY `rs_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `res_category`
--
ALTER TABLE `res_category`
  MODIFY `c_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `u_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users_orders`
--
ALTER TABLE `users_orders`
  MODIFY `o_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
